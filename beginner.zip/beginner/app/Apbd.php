<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Apbd extends Model
{
  protected $guarded = ['id'];
}
