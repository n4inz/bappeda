<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Laporan;
use App\Workshop;
use App\Skpd;
use App\Info;
use App\Surat;
use App\Penelitian;
use App\Apbd;
use App\Rkpd;


class PengurusController extends Controller
{

    public function CariSurat($key)
    {

      $output="";
      $i=1;
      if ($key ==='apa'){
        $surat = Surat::paginate(5);

        foreach($surat as $row){
         $output .= '
                       <tr>'.
                        '<th>'.$i++.'</th>'.
                        '<td>'.$row->judul.'</td>'.
                        '<td>'.$row->file.'</td>'.
                        '<td>'.
                        "<a href='/surat/download/$row->id '>" .'<img src="http://localhost:8000/img/download.png"  >'.
                        "<a href='/surat/delete/$row->id '>" .'<img src="http://localhost:8000/img/hapus.png"  >'
                        .'</td>'.
                       '</tr>
                    ';
        }
      }else{
          $cari = DB::table('surats')
               ->where('judul', 'like', '%'.$key.'%')
               ->orWhere('file', 'like', '%'.$key.'%')
               ->paginate(5);
           $total_row = $cari->count();
           if($total_row > 0){
             foreach($cari as $row){
              $output .= '
              <tr>'.
               '<th>'.$i++.'</th>'.
               '<td>'.$row->judul.'</td>'.
               '<td>'.$row->file.'</td>'.
               '<td>'.
               "<a href='/surat/download/$row->id '>" .'<img src="http://localhost:8000/img/download.png"  >'.
               "<a href='/surat/delete/$row->id '>" .'<img src="http://localhost:8000/img/hapus.png"  >'

               .'</td>'.

              '</tr>.
              ';
             }
           }else{
             $output = '
                        <tr>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                        </tr>
                        ';
           }

      }

      return $output;
    }

    public function index()
    {
      $surat = Surat::all();
      return view('pengurus/index', ['surats' => $surat]);
    }

    public function DownloadSurat($id)
    {
      $download = Surat::find($id);
      return Storage::download("/surat/$download->file");
    }

    public function DeleteSurat($key)
    {
      $DeleteSurat = Surat::find($key);
      $DeleteSurat->delete();
      return redirect('/pengurus');
    }

    public function Info(Request $request)
    {
      return view('pengurus/Info');
    }

    public function InfoPengurus(Request $request)
    {
      $request->validate([
        'info' => 'required'
      ]);
        Info::where('kode','kkl6')->update([
          'kode' => 'kkl6',
          'info' => $request->info,
        ]);

        return redirect('pengurus/info');
    }

    public function ShowInfo()
    {
      $info = Info::all();
      return view('welcome', ['infos' =>$info]);
    }

    public function SearchLaporan($key)
    {
      $output="";
      $i=1;
      if ($key ==='ada'){
        $laporan = Laporan::paginate(5);

        foreach($laporan as $row){
         $output .= '
                       <tr>'.
                        '<th>'.$i++.'</th>'.
                        '<td>'.$row->kegiatan.'</td>'.
                        '<td>'.$row->kegiatan.'</td>'.
                        '<td>'.$row->volume.' '.$row->satuan.'</td>'.
                        '<td>'.$row->paga_pokok.'</td>'.
                        '<td>'.$row->paga_harian.'</td>'.
                        '<td>'.$row->target.'</td>'.
                        '<td>'.$row->realisasi_kegiatan.'</td>'.
                        '<td>'.$row->nama_kegiatan.'</td>'.
                        '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                       '</tr>
                    ';
        }
      }else{
          $cari = DB::table('laporans')
               ->where('kode', 'like', '%'.$key.'%')
               ->orWhere('kegiatan', 'like', '%'.$key.'%')
               ->orWhere('volume', 'like', '%'.$key.'%')
               ->orWhere('satuan', 'like', '%'.$key.'%')
               ->orWhere('paga_pokok', 'like', '%'.$key.'%')
               ->orWhere('paga_harian', 'like', '%'.$key.'%')
               ->orWhere('target', 'like', '%'.$key.'%')
               ->orWhere('realisasi_kegiatan', 'like', '%'.$key.'%')
               ->orWhere('nama_kegiatan', 'like', '%'.$key.'%')
               ->get();
           $total_row = $cari->count();
           if($total_row > 0){
             foreach($cari as $row){
              $output .= '
              <tr>'.
               '<th>'.$i++.'</th>'.
               '<td>'.$row->kegiatan.'</td>'.
               '<td>'.$row->kegiatan.'</td>'.
               '<td>'.$row->volume.' '.$row->satuan.'</td>'.
               '<td>'.$row->paga_pokok.'</td>'.
               '<td>'.$row->paga_harian.'</td>'.
               '<td>'.$row->target.'</td>'.
               '<td>'.$row->realisasi_kegiatan.'</td>'.
               '<td>'.$row->nama_kegiatan.'</td>'.
               '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

              '</tr>.
              ';
             }
           }else{
             $output = '
                        <tr>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                        </tr>
                        ';
           }

      }

      return $output;

    }

    public function ShowLaporan()
    {
      $laporan = Laporan::paginate(5);
      return view('pengurus/DataLaporan', ['laporans' => $laporan]);
    }

    public function SearchWorksop($key)
    {
      $output="";
      $i=1;
      if ($key ==='apa'){
        $workshop = Workshop::paginate(5);

        foreach($workshop as $row){
         $output .= '
                       <tr>'.
                        '<th>'.$i++.'</th>'.
                        '<td>'.$row->nama_instansi.'</td>'.
                        '<td>'.$row->nama_pendaftar.'</td>'.
                        '<td>'.$row->jabatan.'</td>'.
                        '<td>'.$row->alamat.'</td>'.
                        '<td>'.$row->no_hp.'</td>'.
                        '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                       '</tr>
                    ';
        }
      }else{
          $cari = DB::table('workshops')
               ->where('nama_instansi', 'like', '%'.$key.'%')
               ->orWhere('nama_pendaftar', 'like', '%'.$key.'%')
               ->orWhere('jabatan', 'like', '%'.$key.'%')
               ->orWhere('alamat', 'like', '%'.$key.'%')
               ->orWhere('no_hp', 'like', '%'.$key.'%')
               ->get();
           $total_row = $cari->count();
           if($total_row > 0){
             foreach($cari as $row){
              $output .= '
              <tr>'.
               '<th>'.$i++.'</th>'.
               '<td>'.$row->nama_instansi.'</td>'.
               '<td>'.$row->nama_pendaftar.'</td>'.
               '<td>'.$row->jabatan.'</td>'.
               '<td>'.$row->alamat.'</td>'.
               '<td>'.$row->no_hp.'</td>'.
               '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

              '</tr>.
              ';
             }
           }else{
             $output = '
                        <tr>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                        </tr>
                        ';
           }

      }

      return $output;

    }

    public function SearchSkpd($key)
    {
      $output="";
      $i=1;
      if ($key ==='apa'){
        $skpd = Skpd::paginate(5);

        foreach($skpd as $row){
         $output .= '
                       <tr>'.
                        '<th>'.$i++.'</th>'.
                        '<td>'.$row->program_kegiatan.'</td>'.
                        '<td>'.$row->jenis_pendanaan.'</td>'.
                        '<td>'.$row->lokasi.'</td>'.
                        '<td>'.$row->satuan.'</td>'.
                        '<td>'.$row->sasaran.'</td>'.
                        '<td>'.$row->prioritas.'</td>'.
                        '<td>'.$row->jumlah_usulan.'</td>'.
                        '<td>'.$row->jumlah_disetuju_i.'</td>'.
                        '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                       '</tr>
                    ';
        }
      }else{
          $cari = DB::table('skpds')
               ->where('kode_program', 'like', '%'.$key.'%')
               ->orWhere('program_kegiatan', 'like', '%'.$key.'%')
               ->orWhere('lokasi', 'like', '%'.$key.'%')
               ->orWhere('satuan', 'like', '%'.$key.'%')
               ->orWhere('sasaran', 'like', '%'.$key.'%')
               ->orWhere('prioritas', 'like', '%'.$key.'%')
               ->orWhere('jumlah_usulan', 'like', '%'.$key.'%')
               ->orWhere('jumlah_disetuju_i', 'like', '%'.$key.'%')
               ->get();
           $total_row = $cari->count();
           if($total_row > 0){
             foreach($cari as $row){
              $output .= '
              <tr>'.
               '<th>'.$i++.'</th>'.
               '<td>'.$row->program_kegiatan.'</td>'.
               '<td>'.$row->jenis_pendanaan.'</td>'.
               '<td>'.$row->lokasi.'</td>'.
               '<td>'.$row->satuan.'</td>'.
               '<td>'.$row->sasaran.'</td>'.
               '<td>'.$row->prioritas.'</td>'.
               '<td>'.$row->jumlah_usulan.'</td>'.
               '<td>'.$row->jumlah_disetuju_i.'</td>'.
               '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

              '</tr>.
              ';
             }
           }else{
             $output = '
                        <tr>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                        </tr>
                        ';
           }

      }

      return $output;

    }

    public function ShowWorkshop()
    {
      $workshop = Workshop::paginate(5);
      return view('pengurus/DataWorkshop', ['workshops' => $workshop]);
    }

    public function SearchSkpds($key)
    {
      $output="";
      $i=1;
      if ($key ==='apa'){
        $skpd = Skpd::paginate(5);

        foreach($skpd as $row){
         $output .= '
                       <tr>'.
                        '<th>'.$i++.'</th>'.
                        '<td>'.$row->program_kegiatan.'</td>'.
                        '<td>'.$row->jenis_pendanaan.'</td>'.
                        '<td>'.$row->lokasi.'</td>'.
                        '<td>'.$row->satuan.'</td>'.
                        '<td>'.$row->sasaran.'</td>'.
                        '<td>'.$row->prioritas.'</td>'.
                        '<td>'.$row->jumlah_usulan.'</td>'.
                        '<td>'.$row->jumlah_disetuju_i.'</td>'.
                        '<td>'."<a href='/skpd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                       '</tr>
                    ';
        }
      }else{
          $cari = DB::table('skpds')
               ->where('kode_program', 'like', '%'.$key.'%')
               ->orWhere('program_kegiatan', 'like', '%'.$key.'%')
               ->orWhere('lokasi', 'like', '%'.$key.'%')
               ->orWhere('satuan', 'like', '%'.$key.'%')
               ->orWhere('sasaran', 'like', '%'.$key.'%')
               ->orWhere('prioritas', 'like', '%'.$key.'%')
               ->orWhere('jumlah_usulan', 'like', '%'.$key.'%')
               ->orWhere('jumlah_disetuju_i', 'like', '%'.$key.'%')
               ->get();
           $total_row = $cari->count();
           if($total_row > 0){
             foreach($cari as $row){
              $output .= '
              <tr>'.
               '<th>'.$i++.'</th>'.
               '<td>'.$row->program_kegiatan.'</td>'.
               '<td>'.$row->jenis_pendanaan.'</td>'.
               '<td>'.$row->lokasi.'</td>'.
               '<td>'.$row->satuan.'</td>'.
               '<td>'.$row->sasaran.'</td>'.
               '<td>'.$row->prioritas.'</td>'.
               '<td>'.$row->jumlah_usulan.'</td>'.
               '<td>'.$row->jumlah_disetuju_i.'</td>'.
               '<td>'."<a href='/skpd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

              '</tr>.
              ';
             }
           }else{
             $output = '
                        <tr>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                        </tr>
                        ';
           }

      }

      return $output;

    }

    public function ShowSkpd()
    {
      $skpd = Skpd::paginate(5);
      return view('pengurus/DataSkpd', ['skpds' => $skpd]);
    }

    public function SearchPenelitian($key)
    {
      $output="";
      $i=1;
      if ($key ==='apa'){
        $penelitian = Penelitian::paginate(5);

        foreach($penelitian as $row){
         $output .= '
                       <tr>'.
                        '<th>'.$i++.'</th>'.
                        '<td>'.$row->nama.'</td>'.
                        '<td>'.$row->institute.'</td>'.
                        '<td>'.$row->proposal.'</td>'.
                        '<td>'.$row->identitas.'</td>'.
                        '<td>'.$row->jenis_penelitian.'</td>'.
                        '<td>'."<a href='/skpd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                       '</tr>
                    ';
        }
      }else{
          $cari = DB::table('penelitians')
               ->where('nama', 'like', '%'.$key.'%')
               ->orWhere('institute', 'like', '%'.$key.'%')
               ->orWhere('proposal', 'like', '%'.$key.'%')
               ->orWhere('identitas', 'like', '%'.$key.'%')
               ->orWhere('jenis_penelitian', 'like', '%'.$key.'%')
               ->paginate(5);
           $total_row = $cari->count();
           if($total_row > 0){
             foreach($cari as $row){
              $output .= '
              <tr>'.
               '<th>'.$i++.'</th>'.
               '<td>'.$row->nama.'</td>'.
               '<td>'.$row->institute.'</td>'.
               '<td>'.$row->proposal.'</td>'.
               '<td>'.$row->identitas.'</td>'.
               '<td>'.$row->jenis_penelitian.'</td>'.
               '<td>'."<a href='/skpd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

              '</tr>.
              ';
             }
           }else{
             $output = '
                        <tr>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                        </tr>
                        ';
           }

      }

      return $output;
    }

    public function Penelitian(Request $request)
    {

      $request->validate([
        'NamaPendaftar' => 'required',
        'PerguruanTinggi' => 'required',
        'proposal' => 'required',
        'identitas' => 'required',
        'JenisPenelitian' => 'required',
      ]);


      $proposal = $request->file('proposal')->getClientOriginalname();
      $identitas = $request->file('identitas')->getClientOriginalname();
      $file1 = $request->file('proposal');
      $file2 = $request->file('identitas');
      $file1->storeAs('penelitian', $proposal);
      $file2->storeAs('penelitian', $identitas);
      Penelitian::create([
        'nama'             => $request->NamaPendaftar,
        'institute'        => $request->PerguruanTinggi,
        'proposal'         => $proposal,
        'identitas'        => $identitas,
        'jenis_penelitian' => $request->JenisPenelitian,
      ]);

      return redirect('/');

    }

    public function DataPenelitian()
    {

      $DataPenelitian = Penelitian::all();

      return view('/pengurus/DataPenelitian', ['penelitians' => $DataPenelitian]);
    }

    // public function DownloadPenelitian($id)
    // {
    //   $download = Penelitian::find($id);
    //   return Storage::download("/surat/$download->file");
    // }

    public function Apbd()
    {
      $apbd = Apbd::paginate(5);

      return view('/pengurus/Apbd', ['apbds' => $apbd]);
    }

    public function SearchApbd($key)
    {
      $output="";
      $i=1;
      if ($key ==='apa'){
        $apbd = Apbd::paginate(5);

        foreach($apbd as $row){
         $output .= '
                       <tr>'.
                        '<th>'.$i++.'</th>'.
                        '<td>'.$row->KodeApbd.'</td>'.
                        '<td>'.$row->YgBertanggungJawab.'</td>'.
                        '<td>'.$row->Uraian.'</td>'.
                        '<td>'.$row->JumlahAnggaran.'</td>'.
                        '<td>'.$row->SumberDana.'</td>'.
                        '<td>'.$row->Penjelasan.'</td>'.
                        '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                       '</tr>
                    ';
        }
      }else{
          $cari = DB::table('apbds')
               ->where('KodeApbd', 'like', '%'.$key.'%')
               ->orWhere('YgBertanggungJawab', 'like', '%'.$key.'%')
               ->orWhere('Uraian', 'like', '%'.$key.'%')
               ->orWhere('JumlahAnggaran', 'like', '%'.$key.'%')
               ->orWhere('SumberDana', 'like', '%'.$key.'%')
               ->orWhere('Penjelasan', 'like', '%'.$key.'%')
               ->paginate(5);
           $total_row = $cari->count();
           if($total_row > 0){
             foreach($cari as $row){
              $output .= '
              <tr>'.
              '<th>'.$i++.'</th>'.
              '<td>'.$row->KodeApbd.'</td>'.
              '<td>'.$row->YgBertanggungJawab.'</td>'.
              '<td>'.$row->Uraian.'</td>'.
              '<td>'.$row->JumlahAnggaran.'</td>'.
              '<td>'.$row->SumberDana.'</td>'.
              '<td>'.$row->Penjelasan.'</td>'.
               '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

              '</tr>.
              ';
             }
           }else{
             $output = '
                        <tr>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                        </tr>
                        ';
           }

      }

      return $output;
    }

    public function SearchRkpd($key)
    {
      $output="";
      $i=1;
      if ($key ==='apa'){
        $rkpd = Rkpd::paginate(5);

        foreach($rkpd as $row){
         $output .= '
                       <tr>'.
                        '<th>'.$i++.'</th>'.
                        '<td>'.$row->KodeRkpd.'</td>'.
                        '<td>'.$row->YgBertanggungJawab.'</td>'.
                        '<td>'.$row->TaksiranBiaya.'</td>'.
                        '<td>'.$row->SumberDana.'</td>'.
                        '<td>'.$row->WaktuPengerjaan.'</td>'.
                        '<td>'.$row->WaktuPenyelesaiaan.'</td>'.
                        '<td>'.$row->Lokasi.'</td>'.
                        '<td>'.$row->JenisPembangunan.'</td>'.
                        '<td>'.$row->Lampiran.'</td>'.
                        '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                       '</tr>
                    ';
        }
      }else{
          $cari = DB::table('rkpds')
               ->where('KodeRkpd', 'like', '%'.$key.'%')
               ->orWhere('YgBertanggungJawab', 'like', '%'.$key.'%')
               ->orWhere('TaksiranBiaya', 'like', '%'.$key.'%')
               ->orWhere('SumberDana', 'like', '%'.$key.'%')
               ->orWhere('WaktuPengerjaan', 'like', '%'.$key.'%')
               ->orWhere('WaktuPenyelesaiaan', 'like', '%'.$key.'%')
               ->orWhere('Lokasi', 'like', '%'.$key.'%')
               ->orWhere('JenisPembangunan', 'like', '%'.$key.'%')
               ->orWhere('Lampiran', 'like', '%'.$key.'%')
               ->paginate(5);
           $total_row = $cari->count();
           if($total_row > 0){
             foreach($cari as $row){
              $output .= '
              <tr>'.
              '<th>'.$i++.'</th>'.
              '<td>'.$row->KodeRkpd.'</td>'.
              '<td>'.$row->YgBertanggungJawab.'</td>'.
              '<td>'.$row->TaksiranBiaya.'</td>'.
              '<td>'.$row->SumberDana.'</td>'.
              '<td>'.$row->WaktuPengerjaan.'</td>'.
              '<td>'.$row->WaktuPenyelesaiaan.'</td>'.
              '<td>'.$row->Lokasi.'</td>'.
              '<td>'.$row->JenisPembangunan.'</td>'.
              '<td>'.$row->Lampiran.'</td>'.
               '<td>'."<a href='#'>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

              '</tr>.
              ';
             }
           }else{
             $output = '
                        <tr>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                         <td align="center" colspan="2">Data Tidak Ada</td>
                        </tr>
                        ';
           }

      }

      return $output;
    }

    public function Rkpd()
    {
      $rkpd = Rkpd::paginate(5);

      return view('/pengurus/Rkpd' , ['rkpds' => $rkpd]);
    }


}
