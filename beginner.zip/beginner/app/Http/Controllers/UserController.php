<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

use App\Laporan;
use App\Workshop;
use App\Skpd;
use App\Surat;
use App\Apbd;
use App\Rkpd;

class UserController extends Controller
{

  public function __construct()
  {
    $this->middleware('user');
    $this->middleware('auth');
  }

  public function SearchUser($key)
  {
    $output="";
    $i=1;
    if ($key ==='ada'){
      $laporan = Laporan::paginate(5);

      foreach($laporan as $row){
       $output .= '
                     <tr>'.
                      '<th>'.$i++.'</th>'.
                      '<td>'.$row->kegiatan.'</td>'.
                      '<td>'.$row->kegiatan.'</td>'.
                      '<td>'.$row->volume.' '.$row->satuan.'</td>'.
                      '<td>'.$row->paga_pokok.'</td>'.
                      '<td>'.$row->paga_harian.'</td>'.
                      '<td>'.$row->target.'</td>'.
                      '<td>'.$row->realisasi_kegiatan.'</td>'.
                      '<td>'.$row->nama_kegiatan.'</td>'.
                      '<td>'."<a href='/home/laporan/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                     '</tr>
                  ';
      }
    }else{
        $cari = DB::table('laporans')
             ->where('kode', 'like', '%'.$key.'%')
             ->orWhere('kegiatan', 'like', '%'.$key.'%')
             ->orWhere('volume', 'like', '%'.$key.'%')
             ->orWhere('satuan', 'like', '%'.$key.'%')
             ->orWhere('paga_pokok', 'like', '%'.$key.'%')
             ->orWhere('paga_harian', 'like', '%'.$key.'%')
             ->orWhere('target', 'like', '%'.$key.'%')
             ->orWhere('realisasi_kegiatan', 'like', '%'.$key.'%')
             ->orWhere('nama_kegiatan', 'like', '%'.$key.'%')
             ->get();
         $total_row = $cari->count();
         if($total_row > 0){
           foreach($cari as $row){
            $output .= '
            <tr>'.
             '<th>'.$i++.'</th>'.
             '<td>'.$row->kegiatan.'</td>'.
             '<td>'.$row->kegiatan.'</td>'.
             '<td>'.$row->volume.' '.$row->satuan.'</td>'.
             '<td>'.$row->paga_pokok.'</td>'.
             '<td>'.$row->paga_harian.'</td>'.
             '<td>'.$row->target.'</td>'.
             '<td>'.$row->realisasi_kegiatan.'</td>'.
             '<td>'.$row->nama_kegiatan.'</td>'.
             '<td>'."<a href='/home/laporan/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

            '</tr>.
            ';
           }
         }else{
           $output = '
                      <tr>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                      </tr>
                      ';
         }

    }

    return $output;

  }


  public function laporan()
  {
    $laporan = Laporan::paginate(5);
     return view('user/HomeUser',['laporans' => $laporan]);
  }

  public function PostUser(Request $request)
  {

    $request->validate([
      'kode' => 'required',
      'kegiatan' => 'required',
      'volume' => 'required',
      'satuan' => 'required',
      'paga_pokok' => 'required',
      'paga_harian' => 'required',
      'target' => 'required',
      'realisasi_kegiatan' => 'required',
      'nama_kegiatan' => 'required',
    ]);


    Laporan::create([
      'kode' => $request->kode,
      'program' => $request->program,
      'kegiatan' => $request->kegiatan,
      'volume' => $request->volume,
      'satuan' => $request->satuan,
      'paga_pokok' => $request->paga_pokok,
      'paga_harian' => $request->paga_harian,
      'target' => $request->target,
      'realisasi_kegiatan' => $request->realisasi_kegiatan,
      'nama_kegiatan' => $request->nama_kegiatan,
    ]);

    return redirect('/home/laporan');
  }

  public function DeleteLap($id)
  {
    $laporan = Laporan::find($id);
    $laporan->delete();
    return redirect('/home/laporan');

  }

  public function SearchWork($key)
  {
    $output="";
    $i=1;
    if ($key ==='ada'){
      $workshop = Workshop::paginate(5);

      foreach($workshop as $row){
       $output .= '
                     <tr>'.
                      '<th>'.$i++.'</th>'.
                      '<td>'.$row->nama_instansi.'</td>'.
                      '<td>'.$row->nama_pendaftar.'</td>'.
                      '<td>'.$row->jabatan.'</td>'.
                      '<td>'.$row->alamat.'</td>'.
                      '<td>'.$row->no_hp.'</td>'.
                      '<td>'."<a href='/home/workshop/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                     '</tr>
                  ';
      }
    }else{
        $cari = DB::table('workshops')
             ->where('nama_instansi', 'like', '%'.$key.'%')
             ->orWhere('nama_pendaftar', 'like', '%'.$key.'%')
             ->orWhere('jabatan', 'like', '%'.$key.'%')
             ->orWhere('alamat', 'like', '%'.$key.'%')
             ->orWhere('no_hp', 'like', '%'.$key.'%')
             ->get();
         $total_row = $cari->count();
         if($total_row > 0){
           foreach($cari as $row){
            $output .= '
            <tr>'.
             '<th>'.$i++.'</th>'.
             '<td>'.$row->nama_instansi.'</td>'.
             '<td>'.$row->nama_pendaftar.'</td>'.
             '<td>'.$row->jabatan.'</td>'.
             '<td>'.$row->alamat.'</td>'.
             '<td>'.$row->no_hp.'</td>'.
             '<td>'."<a href='/home/workshop/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

            '</tr>.
            ';
           }
         }else{
           $output = '
                      <tr>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                      </tr>
                      ';
         }

    }

    return $output;

  }

  public function workshop()
  {
    $workshop = Workshop::paginate(5);
    return view('user/WorkshopUser' , ['workshops' => $workshop]);
  }

  public function DeleteWork($id)
  {
    $laporan = Workshop::find($id);
    $laporan->delete();
    return redirect('/home/workshop');

  }

  public function WorkshopUser(Request $request)
  {

    $request->validate([
      'nama_instansi' => 'required',
      'nama_pendaftar' => 'required',
      'jabatan' => 'required',
      'alamat' => 'required',
      'no_hp' => 'required',
    ]);

    Workshop::create([
      'nama_instansi' => $request->nama_instansi,
      'nama_pendaftar' => $request->nama_pendaftar,
      'jabatan' => $request->jabatan,
      'alamat' => $request->alamat,
      'no_hp' => $request->no_hp,
    ]);

    return redirect('/home/workshop');
  }

  public function SearchSkpd($key)
  {
    $output="";
    $i=1;
    if ($key ==='ada'){
      $skpd = Skpd::paginate(5);

      foreach($skpd as $row){
       $output .= '
                     <tr>'.
                      '<th>'.$i++.'</th>'.
                      '<td>'.$row->program_kegiatan.'</td>'.
                      '<td>'.$row->jenis_pendanaan.'</td>'.
                      '<td>'.$row->lokasi.'</td>'.
                      '<td>'.$row->satuan.'</td>'.
                      '<td>'.$row->sasaran.'</td>'.
                      '<td>'.$row->prioritas.'</td>'.
                      '<td>'.$row->jumlah_usulan.'</td>'.
                      '<td>'.$row->jumlah_disetuju_i.'</td>'.
                      '<td>'."<a href='/skpd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                     '</tr>
                  ';
      }
    }else{
        $cari = DB::table('skpds')
             ->where('kode_program', 'like', '%'.$key.'%')
             ->orWhere('program_kegiatan', 'like', '%'.$key.'%')
             ->orWhere('lokasi', 'like', '%'.$key.'%')
             ->orWhere('satuan', 'like', '%'.$key.'%')
             ->orWhere('sasaran', 'like', '%'.$key.'%')
             ->orWhere('prioritas', 'like', '%'.$key.'%')
             ->orWhere('jumlah_usulan', 'like', '%'.$key.'%')
             ->orWhere('jumlah_disetuju_i', 'like', '%'.$key.'%')
             ->get();
         $total_row = $cari->count();
         if($total_row > 0){
           foreach($cari as $row){
            $output .= '
            <tr>'.
             '<th>'.$i++.'</th>'.
             '<td>'.$row->program_kegiatan.'</td>'.
             '<td>'.$row->jenis_pendanaan.'</td>'.
             '<td>'.$row->lokasi.'</td>'.
             '<td>'.$row->satuan.'</td>'.
             '<td>'.$row->sasaran.'</td>'.
             '<td>'.$row->prioritas.'</td>'.
             '<td>'.$row->jumlah_usulan.'</td>'.
             '<td>'.$row->jumlah_disetuju_i.'</td>'.
             '<td>'."<a href='/skpd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

            '</tr>.
            ';
           }
         }else{
           $output = '
                      <tr>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                      </tr>
                      ';
         }

    }

    return $output;

  }

  public function skpd()
  {
    $skpd = Skpd::paginate(5);
    return view('user/SkpdUser', ['skpds' => $skpd]);
  }

  public function DeleteSkpd($id)
  {
    $laporan = Skpd::find($id);
    $laporan->delete();
    return redirect('/home/skpd');

  }


  public function skpd_user(Request $request)
  {

    $request->validate([
      'kode_program' => 'required',
      'program_kegiatan' => 'required',
      'jenis_pendanaan' => 'required',
      'lokasi' => 'required',
      'satuan' => 'required',
      'sasaran' => 'required',
      'prioritas' => 'required',
      'jumlah_usulan' => 'required',
      'jumlah_disetuju_i' => 'required',
    ]);

    Skpd::create([
      'kode_program' => $request->kode_program,
      'program_kegiatan' => $request->program_kegiatan,
      'jenis_pendanaan' => $request->jenis_pendanaan,
      'lokasi' => $request->lokasi,
      'satuan' => $request->satuan,
      'sasaran' => $request->sasaran,
      'prioritas' => $request->prioritas,
      'jumlah_usulan' => $request->jumlah_usulan,
      'jumlah_disetuju_i' => $request->jumlah_disetuju_i,
    ]);

    return redirect('home/skpd');
  }

  public function SearchApbd($key)
  {
    $output="";
    $i=1;
    if ($key ==='ada'){
      $apbd = Apbd::paginate(5);

      foreach($apbd as $row){
       $output .= '
                     <tr>'.
                      '<th>'.$i++.'</th>'.
                      '<td>'.$row->KodeApbd.'</td>'.
                      '<td>'.$row->YgBertanggungJawab.'</td>'.
                      '<td>'.$row->Uraian.'</td>'.
                      '<td>'.$row->JumlahAnggaran.'</td>'.
                      '<td>'.$row->SumberDana.'</td>'.
                      '<td>'.$row->Penjelasan.'</td>'.
                      '<td>'."<a href='/apbd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                     '</tr>
                  ';
      }
    }else{
        $cari = DB::table('apbds')
             ->where('KodeApbd', 'like', '%'.$key.'%')
             ->orWhere('YgBertanggungJawab', 'like', '%'.$key.'%')
             ->orWhere('Uraian', 'like', '%'.$key.'%')
             ->orWhere('JumlahAnggaran', 'like', '%'.$key.'%')
             ->orWhere('SumberDana', 'like', '%'.$key.'%')
             ->orWhere('Penjelasan', 'like', '%'.$key.'%')
             ->paginate(5);
         $total_row = $cari->count();
         if($total_row > 0){
           foreach($cari as $row){
            $output .= '
            <tr>'.
             '<th>'.$i++.'</th>'.
             '<td>'.$row->KodeApbd.'</td>'.
             '<td>'.$row->YgBertanggungJawab.'</td>'.
             '<td>'.$row->Uraian.'</td>'.
             '<td>'.$row->JumlahAnggaran.'</td>'.
             '<td>'.$row->SumberDana.'</td>'.
             '<td>'.$row->Penjelasan.'</td>'.
             '<td>'."<a href='/apbd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

            '</tr>.
            ';
           }
         }else{
           $output = '
                      <tr>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                      </tr>
                      ';
         }

    }

    return $output;

  }

  public function Apbd()
  {
    $apbd = Apbd::paginate(5);

    return view('/user/Apbd', [ 'apbds' => $apbd]);
  }

  public function ApbdPost(Request $request)
  {

    $request->validate([
      'KodeApbd' => 'required',
      'YgBertanggungJawab' => 'required',
      'uraian'  => 'required',
      'JumlahAnggaran' => 'required',
      'SumberDana' => 'required',
      'Penjelasan' => 'required',
    ]);

    Apbd::create([
      'KodeApbd' => $request->KodeApbd,
      'YgBertanggungJawab' => $request->YgBertanggungJawab,
      'Uraian' => $request->uraian,
      'JumlahAnggaran' => $request->JumlahAnggaran,
      'SumberDana' => $request->SumberDana,
      'Penjelasan' => $request->Penjelasan,
    ]);

    return redirect('home/apbd');
  }

  public function ApbdDelete($key)
  {
    $apbd = apbd::find($key);
    $apbd->delete();
    return redirect('/home/apbd');

  }

  public function SearchRkpd($key)
  {
    $output="";
    $i=1;
    if ($key ==='ada'){
      $rkpd = Rkpd::paginate(5);

      foreach($rkpd as $row){
       $output .= '
                     <tr>'.
                      '<th>'.$i++.'</th>'.
                      '<td>'.$row->KodeRkpd.'</td>'.
                      '<td>'.$row->YgBertanggungJawab.'</td>'.
                      '<td>'.$row->TaksiranBiaya.'</td>'.
                      '<td>'.$row->SumberDana.'</td>'.
                      '<td>'.$row->WaktuPengerjaan.'</td>'.
                      '<td>'.$row->WaktuPenyelesaiaan.'</td>'.
                      '<td>'.$row->Lokasi.'</td>'.
                      '<td>'.$row->JenisPembangunan.'</td>'.
                      '<td>'.$row->Lampiran.'</td>'.
                      '<td>'."<a href='/rkpd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.
                     '</tr>
                  ';
      }
    }else{
        $cari = DB::table('rkpds')
             ->where('KodeRkpd', 'like', '%'.$key.'%')
             ->orWhere('YgBertanggungJawab', 'like', '%'.$key.'%')
             ->orWhere('TaksiranBiaya', 'like', '%'.$key.'%')
             ->orWhere('SumberDana', 'like', '%'.$key.'%')
             ->orWhere('WaktuPengerjaan', 'like', '%'.$key.'%')
             ->orWhere('WaktuPenyelesaiaan', 'like', '%'.$key.'%')
             ->orWhere('Lokasi', 'like', '%'.$key.'%')
             ->orWhere('JenisPembangunan', 'like', '%'.$key.'%')
             ->orWhere('Lampiran', 'like', '%'.$key.'%')
             ->paginate(5);
         $total_row = $cari->count();
         if($total_row > 0){
           foreach($cari as $row){
            $output .= '
            <tr>'.
             '<th>'.$i++.'</th>'.
             '<td>'.$row->KodeRkpd.'</td>'.
             '<td>'.$row->YgBertanggungJawab.'</td>'.
             '<td>'.$row->TaksiranBiaya.'</td>'.
             '<td>'.$row->SumberDana.'</td>'.
             '<td>'.$row->WaktuPengerjaan.'</td>'.
             '<td>'.$row->WaktuPenyelesaiaan.'</td>'.
             '<td>'.$row->Lokasi.'</td>'.
             '<td>'.$row->JenisPembangunan.'</td>'.
             '<td>'.$row->Lampiran.'</td>'.
             '<td>'."<a href='/rkpd/delete/$row->id '>" .'<img src="https://img.icons8.com/metro/20/000000/trash.png" id="hapus" alt="Employee" >' .'</td>'.

            '</tr>.
            ';
           }
         }else{
           $output = '
                      <tr>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                       <td align="center" colspan="2">Data Tidak Ada</td>
                      </tr>
                      ';
         }

    }

    return $output;
  }

  public function Rkpd()
  {
    $rkpd = Rkpd::paginate(5);
    return view('/user/Rkpd', ['rkpds' => $rkpd]);
  }

  public function RkpdPost(Request $request)
  {
    $request->validate([
      'KodeRkpd' => 'required',
      'YgBertanggungJawab' => 'required',
      'BiayaPembangunan'  => 'required',
      'SumberDana' => 'required',
      'WaktuPengerjaan' => 'required',
      'WaktuPenyelesaian' => 'required',
      'Lokasi' => 'required',
      'JenisPembangunan' => 'required',
    ]);

    $file = $request->file('LampiranPembangunan');
    $name = $request->file('LampiranPembangunan')->getClientOriginalname();
    $path = $file->storeAs('rkpd', $name);

    Rkpd::create([
      'KodeRkpd'  => $request->KodeRkpd,
      'YgBertanggungJawab'  => $request->YgBertanggungJawab,
      'TaksiranBiaya'  => $request->BiayaPembangunan,
      'SumberDana'  => $request->SumberDana,
      'WaktuPengerjaan'  => $request->WaktuPengerjaan,
      'WaktuPenyelesaiaan'  => $request->WaktuPenyelesaian,
      'Lokasi'  => $request->Lokasi,
      'JenisPembangunan'  => $request->JenisPembangunan,
      'Lampiran'  => $name,
    ]);

    return redirect('/home/rkpd');

  }

  public function RkpdDelete($key)
  {
    $apbd = Rkpd::find($key);
    Storage::delete('rkpd/'.$apbd->Lampiran);
    $apbd->delete();
    return redirect('/home/rkpd');
  }


  public function Surat(Request $request)
  {
    $request->validate([
      'judul' => 'required',
      'surat' => 'required|mimes:pdf,doc',
    ]);


    $file = $request->file('surat');
    $name = $request->file('surat')->getClientOriginalname();
    $path = $file->storeAs('surat', $name);

    Surat::create([
      'judul' => $request->judul,
      'file'  => $name,
    ]);

    return redirect('/home');
  }


}
