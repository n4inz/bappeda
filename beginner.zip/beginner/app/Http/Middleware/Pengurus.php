<?php

namespace App\Http\Middleware;

use Closure;
use Auth;
class Pengurus
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

      if (Auth::user()->pengurus == 1){
        return $next($request);
      }

      return redirect('home');
        // if (Auth::check() && Auth::user()->pengurus()){
        //   return $next($request);
        // }
        // return redirect('/home');

    }
}
