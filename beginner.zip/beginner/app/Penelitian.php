<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Penelitian extends Model
{
  protected $guarded = ['id'];
}
