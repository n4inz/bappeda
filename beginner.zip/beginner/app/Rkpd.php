<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rkpd extends Model
{
    protected $guarded = ['id'];
}
