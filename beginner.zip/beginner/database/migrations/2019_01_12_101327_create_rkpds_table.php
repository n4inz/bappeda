<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRkpdsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rkpds', function (Blueprint $table) {
            $table->increments('id');
            $table->string('KodeRkpd');
            $table->string('YgBertanggungJawab');
            $table->string('TaksiranBiaya');
            $table->string('SumberDana');
            $table->string('WaktuPengerjaan');
            $table->string('WaktuPenyelesaiaan');
            $table->string('Lokasi');
            $table->string('JenisPembangunan');
            $table->string('Lampiran');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rkpds');
    }
}
