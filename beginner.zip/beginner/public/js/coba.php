<?php

// $data = $_GET['data'];
//
 echo $_POST['key'];

?>
