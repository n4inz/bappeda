<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Bappeda</title>
  </head>
  <body>
    <hi>Ini halaman bappeda home</h1><br>
      <a href="{{ route('logout')}}">Log out</a>
  </body>
</html>
