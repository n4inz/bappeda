@extends('pengurus.app-Workshop')

@section('content')

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

  </head>
  <body>
    <div class="container">
      <div class="row justify-content-center ">
        <div class="workshop">
          <div class="form-group">
            <div class="col-4">
              <input type="text" class="form-control" placeholder="search" id="keyword">
            </div>
          </div>
          <div class="table-responsive-lg">
            <table class="table" style="width:150%;">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Instansi</th>
                  <th scope="col">Nama</th>
                  <th scope="col">Jabatan</th>
                  <th scope="col">Alamat</th>
                  <th scope="col">No HP</th>
                  <th scope="col">Aksi</th>
                </tr>
              </thead>
              <tbody>
                @php
                  $i=1;
                @endphp
                @foreach($workshops as $workshop)
                <tr>
                  <th scope="row">{{$i++}}</th>
                  <td>{{$workshop->nama_instansi}}</td>
                  <td>{{$workshop->nama_pendaftar}}</td>
                  <td>{{$workshop->jabatan}}</td>
                  <td>{{$workshop->alamat}}</td>
                  <td>{{$workshop->no_hp}}</td>
                  <td>
                    <a href="#"><img src="{{asset('/img/hapus.png')}}"></a>
                  </td>
                </tr>
                  @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="row justify-content-md-center pagtom">
        <div class="col col-3">

        </div>
        <div class="col-6">
        </div>
        <div class="col col-1">
        </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>

@endsection
