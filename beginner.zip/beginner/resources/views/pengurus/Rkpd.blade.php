@extends('pengurus.app-rkpd')

@section('content')
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

  </head>
  <body>
    <div class="container">
      <div class="row justify-content-center ">
        <div class="workshop">
          <div class="form-group">
            <div class="col-4">
              <input type="text" class="form-control" placeholder="search" id="CariRkpd">
            </div>
          </div>
          <div class="table-responsive-lg">
            <table class="table" style="width:250%;">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Kode</th>
                  <th scope="col">Penanggung Jawab</th>
                  <th scope="col">Anggaran</th>
                  <th scope="col">Sumber Dana</th>
                  <th scope="col">Waktu Pengerja'an</th>
                  <th scope="col">Waktu Penyelesai'an</th>
                  <th scope="col">Lokasi</th>
                  <th scope="col">Jenis Pembangunan</th>
                  <th scope="col">Lampiran</th>
                  <th scope="col">Aksi</th>
                </tr>
              </thead>
              <tbody>
                @php
                  $i=1;
                @endphp
                @foreach($rkpds as $rkpd)
                <tr>
                  <th scope="row">{{$i++}}</td>
                  <td>{{$rkpd->KodeRkpd}}</td>
                  <td>{{$rkpd->YgBertanggungJawab}}</td>
                  <td>{{$rkpd->TaksiranBiaya}}</td>
                  <td>{{$rkpd->SumberDana}}</td>
                  <td>{{$rkpd->WaktuPengerjaan}}</td>
                  <td>{{$rkpd->WaktuPenyelesaiaan}}</td>
                  <td>{{$rkpd->Lokasi}}</td>
                  <td>{{$rkpd->JenisPembangunan}}</td>
                  <td><a href="#">{{$rkpd->Lampiran}}</a></td>
                  <td>
                    <a href="#"><img src="{{asset('img/hapus.png')}}"  ></a>
                  </td>
                </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="row justify-content-md-center pagtom">
        <div class="col col-3">

        </div>
        <div class="col-6">
        </div>
        <div class="col col-1">

        </div>
        </div>
    </div>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>

@endsection
