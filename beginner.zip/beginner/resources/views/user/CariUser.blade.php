@extends('user.app-user')

@section('content')

<div class="container">
  <div class="row justify-content-center">
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content ">
          <div class="row justify-content-center">
            <div class="col">
              <img class="img" src="{{asset('img/parepare.png')}}" alt="">
            </div>
          </div>
          <div class="row">
            <div class="col ">
              <h2>INPUT LAPORAN</h2>
            </div>
          </div>
           <form  action="/home/laporan" method="post">
            <div class="form-group row  justify-content-center">
              <div class="col-4">
                <label>Kode</label>
                <input type="text" name="kode" class="form-control form-control-sm">
              </div>

              <div class="col-7">
                <label>Program</label>
                <input type="text" name="program" class="form-control form-control-sm">
              </div>
            </div>

            <div class="form-group row  justify-content-center">
               <div class="col-11">
                 <label>Kegiatan</label>
                 <textarea class="form-control form-control-sm"  name="kegiatan"rows="3"></textarea>
               </div>
            </div>

            <div class="form-group row  justify-content-center">
               <div class="col-6">
                 <label>Volume</label>
                 <input type="text"name="volume" class="form-control form-control-sm">
               </div>

               <div class="col-5">
                 <label>Satuan</label>
                 <input type="text" name=" satuan" class="form-control form-control-sm">
               </div>
            </div>

            <div class="form-group row  justify-content-center">
              <div class="col-6">
                <label>Paga Pokok</label>
                <input type="text" name="paga_pokok" class="form-control form-control-sm">
              </div>

              <div class="col-5">
                 <label>Paga Harian</label>
                 <input type="text" name="paga_harian" class="form-control form-control-sm">
              </div>
            </div>

            <div class="form-group row  justify-content-center">
               <div class="col-7">
                 <label>Target</label>
                 <div class="input-group">
                   <div class="input-group-prepend">
                     <span class="input-group-text" id="validationTooltipUsernamePrepend">Rp</span>
                   </div>
                   <input type="number" name="target" class="form-control form-control-sm" >
                 </div>
               </div>

               <div class="col-4">
                  <label>Realisasi Kegiatan</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="validationTooltipUsernamePrepend">%</span>
                    </div>
                    <input type="number" name="realisasi_kegiatan" class="form-control form-control-sm" >
                  </div>
               </div>
            </div>

            <div class="form-group row justify-content-center">
               <div class="col-11">
                 <label>Nama Kegiatan</label>
                 <textarea class="form-control form-control-sm"  name="nama_kegiatan" rows="3"></textarea>
               </div>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
             {{csrf_field()}}
           </form>
        </div>
      </div>
    </div>

    <form class="form-inline" action="/home/laporan" method="POST">
      <div class="form-group mx-sm-3 mb-2">
        <input type="text" class="form-control" id="inputPassword2" placeholder="search" name="cari">
      </div>
      <button type="submit" class="btn btn-primary mb-2">search</button>
       {{csrf_field()}}
    </form>
    <div class="text">
      <div class="table-responsive-lg">
        <table class="table" style="width:200%;">
          <thead class="bg-success">
            <tr>
              <th scope="col">No</th>
              <th scope="col">Instansi</th>
              <th scope="col">Kegiatan</th>
              <th scope="col">Volume</th>
              <th scope="col">Paga Pokok</th>
              <th scope="col">Paga Harian</th>
              <th scope="col">Target</th>
              <th scope="col">Realisasi Kegiatan</th>
              <th scope="col">Nama Kegiatan</th>
              <th scope="col">Aksi</th>
            </tr>
          </thead>
            @php
              $i=1;
            @endphp
              @foreach($caris as $laporan)
          <tbody>
            <tr>
              <th scope="row">{{$i++}}</th>
              <td>{{$laporan->kegiatan}}</td>
              <td>{{$laporan->kegiatan}}</td>
              <td>{{$laporan->volume}} {{$laporan->satuan}}</td>
              <td>{{$laporan->paga_pokok}}</td>
              <td>{{$laporan->paga_harian}}</td>
              <td>{{$laporan->target}}</td>
              <td>{{$laporan->realisasi_kegiatan}}</td>
              <td>{{$laporan->nama_kegiatan}}</td>
              <td>
                <a href="/home/laporan/{{$laporan->id}}">
                  <img src="../img/hapus.png" alt="Employee" >
                </a>
              </td>
            </tr>
          </tbody>
          @endforeach
        </table>
      </div>
    </div>
  </div>

  <div class="row justify-content-md-center pagtom">
    <div class="col col-1">
      <button type="button" class="btn btn-primary btn-laporan" data-toggle="modal" data-target="#exampleModalCenter">
        Buat Laporan
      </button>
    </div>
    <div class="col-6">
    </div>

    </div>
</div>
@endsection
