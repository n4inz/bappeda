<?php

Route::get('/', 'PengurusController@ShowInfo');

Auth::routes();
Route::get('/home', 'HomeController@index')->middleware('user');

Route::group(['prefix' => 'admin'], function(){
  Route::get('/login', 'AuthAdmin\LoginController@showLoginForm')->name('admin.login');
  Route::post('/login', 'AuthAdmin\LoginController@login')->name('admin.login.submit');
  Route::get('/', 'AdminController@index')->name('admin.home');
});

Route::get('/pengurus','PengurusController@index')->middleware('pengurus','auth')->name('home');


Route::get('/home/laporan','UserController@laporan');
Route::post('/home/laporan','UserController@PostUser');
Route::get('/home/get/{data}', 'UserController@SearchUser');
Route::get('/home/laporan/{id}', 'UserController@DeleteLap');

Route::get('/home/workshop','UserController@workshop');
Route::post('/home/workshop','UserController@WorkshopUser');
Route::get('/workshop/{key}','UserController@SearchWork');
Route::get('/home/workshop/{id}' , 'UserController@DeleteWork');


Route::get('/home/skpd','UserController@skpd');
Route::post('/home/skpd','UserController@skpd_user');
Route::get('/skpd/{key}','UserController@SearchSkpd');
Route::get('/skpd/delete/{key}','UserController@DeleteSkpd');

Route::post('/surat', 'UserController@Surat');
Route::get('/surat/download/{id}','PengurusController@DownloadSurat');
Route::get('/surat/search/{key}','PengurusController@CariSurat');
Route::get('/surat/delete/{key}', 'PengurusController@DeleteSurat');

Route::get('/home/apbd', 'UserController@Apbd');
Route::post('/home/apbd', 'UserController@ApbdPost');
Route::get('/apbd/{key}', 'UserController@SearchApbd');
Route::get('/apbd/delete/{key}' ,'UserController@ApbdDelete');

Route::get('/home/rkpd', 'UserController@Rkpd');
Route::post('/home/rkpd', 'UserController@RkpdPost');
Route::get('/rkpd/{key}', 'UserController@SearchRkpd');
Route::get('/rkpd/delete/{key}' ,'UserController@RkpdDelete');


Route::get('/pengurus/DataLaporan', 'PengurusController@ShowLaporan');
Route::get('/pengurus/datalaporan/search/{key}', 'PengurusController@SearchLaporan');

Route::get('/pengurus/DataWorkshop', 'PengurusController@ShowWorkshop');
Route::get('/pengurus/dataworkshop/search/{key}', 'PengurusController@SearchWorksop');

Route::get('/pengurus/DataSkpd', 'PengurusController@ShowSkpd');
Route::get('/pengurus/dataskpd/search/{key}', 'PengurusController@SearchSkpds');

Route::get('/pengurus/info', 'PengurusController@Info');
Route::post('/pengurus/info', 'PengurusController@InfoPengurus');

Route::post('/pengurus/penelitian', 'PengurusController@Penelitian');
Route::get('/pengurus/DataPenelitian', 'PengurusController@DataPenelitian');
Route::get('/penelitian/search/{key}', 'PengurusController@SearchPenelitian');

Route::get('/pengurus/apbd', 'PengurusController@Apbd');
Route::get('/apbd/search/{key}', 'PengurusController@SearchApbd');

Route::get('/pengurus/rkpd', 'PengurusController@Rkpd');
Route::get('/rkpd/search/{key}', 'PengurusController@SearchRkpd');


Route::get('/pengurus/register',function(){
  return view('pengurus/register');
});
Route::get('inputan',function(){
  return view('inputan');
});
