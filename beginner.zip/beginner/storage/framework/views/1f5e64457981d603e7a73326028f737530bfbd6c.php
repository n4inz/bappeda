<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-8">
          <form action="/surat" enctype="multipart/form-data" method="post">
             <?php echo e(csrf_field()); ?>

            <div class="panel-heading"><h2>Kirim Surat</h2></div>
            <div class="panel-body">
              <div class="form-group row">
                 <div class="col-11">
                   <label>Judul</label>
                   <textarea class="form-control form-control-sm is-valid" name="judul" rows="5"></textarea>
                   <div class="valid-feedback" style="color:red;">
                     <?php echo e($errors->first('judul')); ?>

                   </div>
                 </div>
              </div>

              <div class="form-group row">
                <div class="col-5">
                  <div class="custom-file">
                   <input type="file" class="custom-file-input is-valid" name="surat" id="validatedCustomFile">
                   <label class="custom-file-label" for="validatedCustomFile">Choose file</label>
                 </div>
                 <div style="color:red; font-size:13px;">
                   <?php echo e($errors->first('surat')); ?>

                 </div>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-4">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </div>
            </div>
          </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>