<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="<?php echo e(asset('css/sidebar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/content.css')); ?>" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
</head>
<body>
  <nav class="navbar navbar-expand-lg ">
    <img src="<?php echo e(asset('img/parepare.png')); ?>" alt="">
    <a class="navbar-brand" href="#">BAPPEDA PAREPARE</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           <?php echo e(Auth::user()->name); ?>

          </a>
          <div class="dropdown-menu" >
            <a class="dropdown-item" href="#">Register</a>
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();">
                Logout
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
          </div>
        </li>
      </ul>
    </div>
  </nav>
<!-- Awal Sidebar -->
  <div class="sidebar">
    <div class="row">
      <div class="col">
        <img src="http://via.placeholder.com/160x160" alt="">
      </div>
      <div class="col">
        <p><?php echo e(Auth::user()->name); ?></p>
        <p>Online</p>
      </div>
    </div>
    <ul>
      <div class="navigasi">
        <p>NAVIGASI</p>
      </div>
    <nav>
      <ul class="drop-down closed">
        <li><a href="/home">Dashboard</a>
          <div class="nav-button demo-arrow-right"></div>
        </li>
        <li><a href="/pengurus/DataLaporan">Data Laporan</a></li>
        <li><a href="/pengurus/DataWorkshop">Data Workshop</a></li>
        <li><a href="/pengurus/DataSkpd">SKPD</a></li>
      </ul>
    </nav>
        <li><a href="/pengurus/info">Info</a></li>
        <li><a href="/pengurus/DataPenelitian">Data Penelitian</a></li>
        <li><a href="/pengurus/apbd">Apbd</a></li>
        <li><a href="/pengurus/rkpd">Rkpd</a></li>
    </ul>
  </div>

        <!-- Akhir Sidebar -->
        <?php echo $__env->yieldContent('content'); ?>





</body>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script type="text/javascript">

    // $(document).ready(function(){
    //   $("#CariSurat").keyup(function(){
    //     var val = $(this).val();
    //     var key = 'apa';
    //     $.ajax({
    //       url : "/surat/search/"+val,
    //       method : "GET",
    //       success : function (data){
    //       $('tbody').html(data);
    //     });
    //   });
    // });

    $('document').ready(function(){
      $('#CariSurat').keyup(function(){
        var key = $(this).val();
        var val = 'ada';
        if( key === ""){
          $.ajax({
            url : "surat/search/"+val,
            method :"GET",
            success : function(data){
            $('tbody').html(data);

            },

          });
        }else{
          $.ajax({
            url : "surat/search/"+key,
            method :"GET",
            success : function(data){
            $('tbody').html(data);

            },

          });
        }
      })
    })


        $(function() {
          $(".nav-button").click(function() {
            $(this).parent().parent().toggleClass("closed");
          });
        });



    </script>

</html>
