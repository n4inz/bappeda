<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

  </head>
  <body>

    <div class="container">
      <div class="row justify-content-center">
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
              <div class="row justify-content-center">
                <div class="col">
                  <img src="<?php echo e(asset('img/parepare.png')); ?>" alt="">
                  <h2>Pendaftaran Workshop</h2>
                </div>
              </div>
              <form class="" action="/home/workshop" method="post">
                <div class="form-group row  justify-content-center">
                  <div class="col-5">
                    <label>Nama Instansi</label>
                    <input type="text" name="nama_instansi" class="form-control form-control-sm">
                  </div>

                  <div class="col-sm-5">
                    <label>Nama Pendaftar</label>
                    <input type="text" name="nama_pendaftar" class="form-control form-control-sm">
                  </div>
                </div>

                <div class="form-group row  justify-content-center">
                  <div class="col-sm-6">
                    <label>Jabatan</label>
                    <input type="text" name="jabatan" class="form-control form-control-sm">
                  </div>

                  <div class="col-sm-4">
                    <label>No Hp</label>
                    <input type="number" name="no_hp" class="form-control form-control-sm">
                  </div>
                </div>

                <div class="form-group row  justify-content-center">
                   <div class="col-10">
                     <label>Alamat</label>
                     <textarea class="form-control form-control-sm" name="alamat" rows="3"></textarea>
                   </div>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Daftar</button>
                </div>
                <?php echo e(csrf_field()); ?>

              </form>
            </div>
          </div>
        </div>

        <div class="workshop">
          <div class="form-group">
            <div class="col-4">
              <input type="text" class="form-control" placeholder="search" id="cariWork">
            </div>
          </div>
          <div class="table-responsive-lg">
              <table class="table" style="width:150%;">
                <thead class="bg-success">
                  <tr>
                  <th scope="col">No</th>
                    <th scope="col">Instansi</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Jabatan</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">No HP</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>

                <tbody >
                  <?php
                   $i=1;
                 ?>
                  <?php $__currentLoopData = $workshops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workshop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div id="container">
                    <tr>
                       <th scope="row"><?php echo e($i++); ?></th>
                       <td><?php echo e($workshop->nama_instansi); ?></td>
                       <td><?php echo e($workshop->nama_pendaftar); ?></td>
                       <td><?php echo e($workshop->jabatan); ?></td>
                       <td><?php echo e($workshop->alamat); ?></td>
                       <td><?php echo e($workshop->no_hp); ?></td>
                      <td>
                        <a href="/home/workshop/<?php echo e($workshop->id); ?>">
                          <img src='https://img.icons8.com/metro/20/000000/trash.png' alt="Employee" >
                        </a>
                      </td>
                    </tr>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </div>
        </div>

      </div>
      <div class="row justify-content-md-center pagtom">
        <div class="col col-1">
          <button type="button" class="btn btn-primary btn-laporan" data-toggle="modal" data-target="#exampleModalCenter">
            Workshop
          </button>
        </div>
        <div class="col-6">

        </div>
        <div class="col col-1">
          <?php echo e($workshops->links('vendor.pagination.pagination', ['foo' => 'bar'])); ?>

        </div>
      </div>
    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.app-workshop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>