<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <!-- My font viga -->
      <link href="https://fonts.googleapis.com/css?family=Viga" rel="stylesheet">
    <!-- My font viga -->
    <!-- MY CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <!-- MY CSS -->
    <title>Bappeda</title>
  </head>
  <body>
    <!-- Button trigger modal -->
    <!-- Modal informasi-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">INFORMASI</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($info->info); ?>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Penelitian -->
    <div class="modal fade" id="penelitian" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
          <div class="row img">
            <div class="col">
              <img src="<?php echo e(asset('img/parepare.png')); ?>" alt="">
              <h2>Pendaftaran Penelitian</h2>
            </div>
          </div>
          <form  action="/pengurus/penelitian" enctype="multipart/form-data" method="post">
          <?php echo e(csrf_field()); ?>

          <div class="form-group row  justify-content-center">
            <div class="col-sm-5">
              <label>Nama Pendaftar</label>
              <input type="text" name="NamaPendaftar" class="form-control form-control-sm">
            </div>

            <div class="col-sm-6">
              <label>Perguruan Tinggi</label>
              <input type="text" name="PerguruanTinggi" class="form-control form-control-sm">
            </div>
          </div>

          <div class="form-group row  justify-content-center">
            <div class="col-sm-5">
              <label>Proposal</label>
              <div class="custom-file">
               <input type="file" class="custom-file-input" name="proposal" id="customFile">
               <label class="custom-file-label" for="customFile">Choose file</label>
             </div>
            </div>
            <div class="col-sm-6">
              <label>Lampiran Foto Identitas</label>
              <div class="custom-file">
               <input type="file" class="custom-file-input" name="identitas" id="customFile">
               <label class="custom-file-label" for="customFile">Choose file</label>
             </div>
            </div>
          </div>

          <div class="form-group row  justify-content-center">
            <div class="col-sm-6">
              <label>Jenis Penelitian</label>
              <select id="inputState" class="form-control" name="JenisPenelitian">
                <option selected>Pilih</option>
                <option value="Riset">Riset</option>
                <option value="Observasi">Observasi</option>
                <option value="Survei">Survei</option>
                <option value="Wawancara">Wawancara</option>
                <option value="Studi Kasus">Studi Kasus</option>
                <option value="Polling/Jejak Pendapat">Polling/Jejak Pendapat</option>
                <option value="Angket">Angket</option>
                <option value="Pendataan">Pendataan</option>
              </select>
            </div>

            <div class="col-sm-5">
            </div>
          </div>

          <div class="modal-footer">
            <div class="col-9">
              <span>Syarat dan ketentuan di <a data-toggle="modal" data-target="#SyaratKetentuan" href="#">sini</a></span>
            </div>
            <div class="col-3">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </div>
        </form>
        </div>
      </div>
    </div>

    <!-- Syarat dan ketentuan -->
    <div class="modal fade" id="SyaratKetentuan" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">INFORMASI</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>


  <!-- NAVBAR -->
   <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <a class="navbar-brand" href="#">BAPPEDA</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
       <div class="navbar-nav ml-auto">
       <a class="nav-item nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
       <a class="nav-item nav-link" href="#">Pricing</a>
       <a class="nav-item nav-link" data-toggle="modal" data-target="#penelitian" href="#">Penelitian</a>
       <a class="nav-item nav-link" data-toggle="modal" data-target="#exampleModal" href="#">Info</a>
       <a class="nav-item btn btn-primary tombol" href="/login">Join us</a>
       </div>
      </div>
    </div>
   </nav>
  <!-- AKHIR NAVBAR -->
  <!-- JUMBO TRON -->
  <div class="jumbotron jumbotron-fluid">
    <div class="container">
     <h1 class="display-4">Selesaikan pekerjaan <span>lebih cepat</span> <br>dan <span>lebih baik</span> dengan kami</h1>
     <a href="/login" class="nav-item btn btn-primary tombol">MARI BEKERJA</a>
    </div>
  </div>
  <!-- AKHIR JUMBO TRON -->

  <!-- Container -->
  <div class="container">
    <!-- Info Panel -->
    <div class="row justify-content-center">
      <div class="col-10 info-panel">
        <div class="row">
          <div class="col-lg">
            <img src="img/jokowi.jpeg" alt="Employee" class="float-left rounded-circle">
            <h4>Ir. H. Joko Widodo</h4>
            <p>Presiden Republik indonesia 2014-2019</p>
          </div>
          <div class="col-lg">
            <img src="img/nurdin.jpg" alt="High Res" class="float-left rounded-circle">
            <h5>Prof. Dr. Ir. H.M. Nurdin Abdullah, M.Agr</h5>
            <p>Gubernur Sulsel 2018-2023</p>
          </div>
          <div class="col-lg">
            <img src="img/taufan.jpeg" alt="Security" class="float-left rounded-circle">
            <h5>Dr. H.Taufan Pawe, S.H, M.H</h5>
            <p>Walikota Parepare 2018-2023</p>
          </div>
        </div>
      </div>
    </div>
    <!-- Akhir Info Panel -->

    <!-- Working Space -->

    <!-- Akhir Working Space -->
    <!-- Testimonial -->
    <div class="container">
    <hr>
          <section class="testimonial">
            <div class="row justify-content">
              <div class="col-lg">
                <h5>Apa itu Bappeda?</h5>
                <p>Badan Perencanaan Pembangunan Daerah, disingkat Bappeda, adalah lembaga teknis daerah dibidang penelitian
                  dan perencanaan pembangunan daerah yang dipimpin oleh seorang kepala
                  badan yang berada dibawah dan bertanggung jawab kepada Gubernur/Bupati/Wali kota
                  melalui Sekretaris Daerah. Badan ini mempunyai tugas pokok membantu Gubernur/Bupati/Wali kota
                  dalam penyelenggaraan Pemerintahan Daerah dibidang penelitian dan perencanaan pembangunan daerah.</p>
              </div>
              <div class="struktur-organisasi">
                <img src="img/organisasi.png">
              </div>
            </div>
          </section>
    <hr>
    </div>

    <section class="testimonial2">
      <div class="row justify-content-center">
        <div>
          <h2>Tugas Pokok Dan Fungsi</h2>
        </div>
      </div>
      <div class="row justify-content-center">
        <div class="col-lg">
          <p>
            1. Penyusunan dan pelaksanaan Rencana Kerja dan Anggaran Badan Perencanaan Pembangunan Daerah
            <br>2. Perumusan kebijakan perencanaan pembangunan, penelitian dan pengembangan serta statistik daerah;
            <br>3. Pengoordinasian penyusunan Rencana Tata Ruang Wilayah (RTRW).
            <br>4. Penyusunan Kebijakan Umum Anggaran (KUA) berkoordinasi dengan Bagian Pengelola Keuangan Daerah;
            <br>5. Penyusunan Prioritas dan Plafon Anggaran (PPA) berkoordinasi dengan Bagian Pengelola Keuangan Daerah;
            <br>6. Pengendalian kesesuaian antaran indikator, kinerja RKPD dengan Kebijakan Umum Anggaran (KUA) dan Prioritas dan Plafon Anggaran (PPA).
            <br>7. Pengoordinasian kebijakan perencanaan di bidang pembangunan perekonomian.
            <br>8. Pengoordinasian perencanaan pembangunan secara terpadu lintas negara, lintas daerah, lintas urusan pemerintah.
            <br>9. Evaluasi pelaksanaan rencana pembangunan;
            <br>10.Penyelenggaraan pengoordinasian penelitian dan pengembangan daerah;
            <br>11.Penyelenggaraan pengoordinasian statistik daerah;
            <br>12.Penyediaan, penatausahaan, penggunaan, pemeliharaan, dan perawatan prasarana dan sarana kerja Bappeda;
            <br>13.Pemberian dukungan teknis perencanaan pembangunan kepada perangkat daerah;
            <br>14.Pengoordinasian penyusunan laporan kinerja pemerintah daerah;
            <br>15.Pengelolaan kepegawaian, keuangan, barang dan ketatausahaan Bappeda; dan
            16.Pelaporan, dan pertanggungjawaban pelaksanaan tugas dan fungsi.
          </p>
        </div>
      </div>
    </section>
    <!-- Akhir Testimonial -->
  </div>
  <!-- Peta -->
<section>
  <div class="col-lg kantor">
    <img class="img1" src="img/scooter.png">
    <img class="img2" src="img/center.png">
    <h2>Alamat Kantor</h2>
  </div>
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3514.842217977135!2d119.63058154994079!3d-4.028551397056031!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2d95bb6f2a4f395f%3A0x13406bfe9c84085e!2sBappeda+Kota+Parepare!5e1!3m2!1sid!2sid!4v1542023757058" width="1307" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</section>

  <!-- Akhir peta -->

  <!-- Akhir Container -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script type="text/javascript">
      $('#exampleModal').modal('show')
    </script>
  </body>
</html>
