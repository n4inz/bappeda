<?php $__env->startSection('content'); ?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

  </head>
  <body>
    <div class="container">
      <div class="row justify-content-center ">
        <div class="workshop">
          <div class="form-group">
            <div class="col-4">
              <input type="text" class="form-control" placeholder="search" id="CariApbd">
            </div>
          </div>
          <div class="table-responsive-lg">
            <table class="table" style="width:100%;">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Kode</th>
                  <th scope="col">Penanggung Jawab</th>
                  <th scope="col">Uraian</th>
                  <th scope="col">Jumlah Anggaran</th>
                  <th scope="col">Sumber Dana</th>
                  <th scope="col">Penjelasan</th>
                  <th scope="col">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  $i=1;
                ?>
                <?php $__currentLoopData = $apbds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apbd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($i++); ?></th>
                  <td><?php echo e($apbd->KodeApbd); ?></td>
                  <td><?php echo e($apbd->YgBertanggungJawab); ?></td>
                  <td><?php echo e($apbd->Uraian); ?></td>
                  <td><?php echo e($apbd->JumlahAnggaran); ?></td>
                  <td><?php echo e($apbd->SumberDana); ?></td>
                  <td><?php echo e($apbd->Penjelasan); ?></td>
                  <td>
                    <a href="#"><img src="<?php echo e(asset('img/hapus.png')); ?>"  ></a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="row justify-content-md-center pagtom">
        <div class="col col-3">

        </div>
        <div class="col-6">
        </div>
        <div class="col col-1">

        </div>
        </div>
    </div>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengurus.app-apbd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>